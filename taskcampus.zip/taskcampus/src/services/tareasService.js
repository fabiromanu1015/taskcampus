const API_URL = "https://jsonplaceholder.typicode.com/todos";

// Lista de tareas académicas en español
const tareasEnEspanol = [
  "Estudiar Ecuaciones Diferenciales",
  "Estudiar Termodinámica",
  "Repasar Álgebra Lineal",
  "Preparar laboratorio de Física",
  "Leer capítulo de Cálculo Multivariable",
  "Resolver guía de Mecánica de Fluidos",
  "Estudiar para prueba de Programación",
  "Repasar Química General"
];

export const getTareas = async (limite = 8) => {
  const res = await fetch(`${API_URL}?_limit=${limite}`);
  if (!res.ok) throw new Error("Error al obtener tareas");
  const datos = await res.json();

  // Reemplazamos el título en latín/inglés por nuestros títulos en español
  return datos.map((item, index) => ({
    ...item,
    title: tareasEnEspanol[index] || `Tarea de estudio #${item.id}`
  }));
};

export const postTarea = async (titulo) => {
  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ title: titulo, completed: false, userId: 1 }),
  });
  if (!res.ok) throw new Error("Error al crear tarea");
  return await res.json();
};

export const putTarea = async (id, datos) => {
  const res = await fetch(`${API_URL}/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(datos),
  });
  if (!res.ok) throw new Error("Error al actualizar tarea");
  return await res.json();
};

export const deleteTarea = async (id) => {
  const res = await fetch(`${API_URL}/${id}`, { method: "DELETE" });
  if (!res.ok) throw new Error("Error al eliminar tarea");
};