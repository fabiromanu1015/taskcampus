import { useState } from "react";
import Button from "./Button";
import Badge from "./Badge";

const TaskItem = ({ tarea, onToggle, onEliminar, onEditarTitulo, deshabilitado }) => {
  const [editando, setEditando] = useState(false);
  const [nuevoTitulo, setNuevoTitulo] = useState(tarea.titulo);

  const guardar = () => {
    if (nuevoTitulo.trim().length >= 3 && nuevoTitulo !== tarea.titulo) {
      onEditarTitulo(tarea.id, { titulo: nuevoTitulo.trim() });
    } else {
      setNuevoTitulo(tarea.titulo);
    }
    setEditando(false);
  };

  return (
    <li className="task-item">
      <div style={{ display: "flex", alignItems: "center", gap: "10px", flex: 1 }}>
        <Badge
          texto={tarea.completada ? "completada" : "pendiente"}
          onClick={() => !deshabilitado && onToggle(tarea.id, tarea.completada)}
        />
        {editando ? (
          <input
            type="text"
            className="task-input"
            value={nuevoTitulo}
            onChange={(e) => setNuevoTitulo(e.target.value)}
            onBlur={guardar}
            onKeyDown={(e) => e.key === "Enter" && guardar()}
            autoFocus
          />
        ) : (
          <span
            onDoubleClick={() => !deshabilitado && setEditando(true)}
            title="Haz doble clic para editar"
            className={tarea.completada ? "task-item-completed" : "task-item-pending"}
            style={{ cursor: "pointer" }}
          >
            {tarea.titulo}
          </span>
        )}
      </div>
      <div style={{ display: "flex", gap: "8px", flexShrink: 0 }}>
        <Button
          label={tarea.completada ? "Desmarcar" : "Completar"}
          onClick={() => onToggle(tarea.id, tarea.completada)}
          variant={tarea.completada ? "success" : "primary"}
          disabled={deshabilitado}
        />
        <Button
          label="Eliminar"
          onClick={() => onEliminar(tarea.id)}
          variant="danger"
          disabled={deshabilitado}
        />
      </div>
    </li>
  );
};

export default TaskItem;