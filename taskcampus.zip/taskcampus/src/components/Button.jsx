const Button = ({ label, onClick, variant = "primary", disabled = false, icon }) => {
  return (
    <button
      className={`btn btn-${variant}`}
      onClick={onClick}
      disabled={disabled}
    >
      {icon && <span style={{ marginRight: "6px" }}>{icon}</span>}
      {label}
    </button>
  )
}

export default Button