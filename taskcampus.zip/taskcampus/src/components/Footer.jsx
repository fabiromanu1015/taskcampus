function Footer({ course }) {
  return (
    <footer>
      <p>Curso: {course}</p>
    </footer>
  )
}

export default Footer