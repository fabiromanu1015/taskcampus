import Button from "./Button"

const Modal = ({ visible, mensaje, onConfirmar, onCancelar }) => {
  if (!visible) return null

  return (
    <div className="modal-overlay">
      <div className="modal-box">
        <p style={{ fontSize: "1.1rem", fontWeight: "500" }}>{mensaje}</p>
        <div className="modal-acciones">
          <Button label="Confirmar" onClick={onConfirmar} variant="danger" />
          <Button label="Cancelar" onClick={onCancelar} variant="secondary" />
        </div>
      </div>
    </div>
  )
}

export default Modal