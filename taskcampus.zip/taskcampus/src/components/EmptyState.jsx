const EmptyState = ({ mensaje = "No hay tareas registradas", icono = "📋" }) => {
  return (
    <div className="empty-state">
      <span style={{ fontSize: "2rem", display: "block", marginBottom: "8px" }}>{icono}</span>
      <p style={{ color: "#64748b", margin: 0, fontStyle: "italic" }}>{mensaje}</p>
    </div>
  )
}

export default EmptyState