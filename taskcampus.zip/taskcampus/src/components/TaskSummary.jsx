const TaskSummary = ({ total, completadas, pendientes, mostrando, filtroActual }) => {
  return (
    <div className="summary-grid">
      <div className="summary-item">
        <span className="summary-numero num-total">{total}</span>
        <span className="summary-label">Total</span>
      </div>
      <div className="summary-item">
        <span className="summary-numero num-completadas">{completadas}</span>
        <span className="summary-label">Completadas</span>
      </div>
      <div className="summary-item">
        <span className="summary-numero num-pendientes">{pendientes}</span>
        <span className="summary-label">Pendientes</span>
      </div>
      <div className="summary-item">
        <span className="summary-numero num-mostrando">{mostrando}</span>
        <span className="summary-label">Mostrando ({filtroActual})</span>
      </div>
    </div>
  );
};

export default TaskSummary;