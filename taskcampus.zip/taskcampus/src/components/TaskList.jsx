import { useState } from "react";
import Button from "./Button";
import TaskItem from "./TaskItem";

const TaskList = ({
  tareas = [],
  filtro,
  onCambiarFiltro,
  onToggle,
  onEliminar,
  onEditarTitulo,
  deshabilitado,
}) => {
  const [busqueda, setBusqueda] = useState("");

  const tareasFiltradas = tareas.filter((t) => {
    const coincideTexto = t.titulo.toLowerCase().includes(busqueda.toLowerCase());
    return coincideTexto;
  });

  return (
    <div>
      {/* Input de Busqueda (Filtro por texto) */}
      <div style={{ marginBottom: "12px" }}>
        <input
          type="text"
          placeholder="🔍 Buscar tarea..."
          className="task-input"
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
        />
      </div>

      {/* Botones de Filtro Levantados */}
      <div style={{ display: "flex", gap: "8px", marginBottom: "12px" }}>
        <Button
          label="📋 Todas"
          onClick={() => onCambiarFiltro("todas")}
          variant={filtro === "todas" ? "primary" : "secondary"}
        />
        <Button
          label="⏳ Pendientes"
          onClick={() => onCambiarFiltro("pendientes")}
          variant={filtro === "pendientes" ? "primary" : "secondary"}
        />
        <Button
          label="✅ Completadas"
          onClick={() => onCambiarFiltro("completadas")}
          variant={filtro === "completadas" ? "primary" : "secondary"}
        />
      </div>

      {tareasFiltradas.length === 0 && (
        <p style={{ textAlign: "center", color: "#94a3b8" }}>
          No hay tareas en esta categoría 🎉
        </p>
      )}

      <ul className="task-list">
        {tareasFiltradas.map((tarea) => (
          <TaskItem
            key={tarea.id}
            tarea={tarea}
            onToggle={onToggle}
            onEliminar={onEliminar}
            onEditarTitulo={onEditarTitulo}
            deshabilitado={deshabilitado}
          />
        ))}
      </ul>
    </div>
  );
};

export default TaskList;